#include "CreatePPM.c"
#include "GetRPixel.c"
#include "GetGPixel.c"
#include "GetBPixel.c"
#include "PutRPixel.c"
#include "PutGPixel.c"
#include "PutBPixel.c"
#include "ReadPPM.c"
#include "WritePPM.c"


