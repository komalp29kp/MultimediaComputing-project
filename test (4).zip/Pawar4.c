/*Assignment 4 Pawar Tiny c*/
#include "PPMTools.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
/* To get the minimum value here we are using the function minvalue*/
int minValue(int var1, int var2) {
  if(var1 < var2) {
    return var1;
  }
  return var2;
}
/* function to convert the rgb value to gray*/
double rgbtogray(int red, int green, int blue) {
  return (red*0.2989)+(green*0.5870)+(blue*0.114);
}
/* Here we are calculating mean adaptive threshold value */
double CalculateMeanAdaptiveThreshold(unsigned char *image, int cols, int rows, int imagex, int imagey, int width) {

  double mean = 0;
  int count = 0;
   for(int i = imagex; i < minValue(imagex + width, cols); i++) {
    for(int j = imagey; j < minValue(imagey + width, rows); j++) {
      count++;
      mean += rgbtogray(GetRPixel(image, cols, i, j), GetGPixel(image, cols, i, j), GetBPixel(image, cols, i, j));
    }
  }
  return mean / count;
}
/*function to get the Adaptive Mean Threshold Value*/
void AdaptiveMeanThreshold(unsigned char *image, unsigned char *output, int cols, int rows, int width) {
  for(int imagex = 0; imagex < cols; imagex += width) {
    for(int imagey = 0; imagey < rows; imagey += width) {
      double threshold = CalculateMeanAdaptiveThreshold(image, cols, rows, imagex, imagey, width);
      for(int i = imagex; i < minValue(imagex + width, cols); i++) {
        for(int j = imagey; j < minValue(imagey + width, rows); j++) {
          if(rgbtogray(GetRPixel(image, cols, i, j), GetGPixel(image, cols, i, j), GetBPixel(image, cols, i, j)) < threshold) {
            PutBPixel(output, cols, i, j, 0);
            PutGPixel(output, cols, i, j, 0);
            PutRPixel(output, cols, i, j, 0);
          }
        }
      }
    }
  }
}
/* Here I have created a function to calculate mean single threshold value*/
double CalculateMeanSingleThreshold(unsigned char *image, int cols, int rows) {
  double mean = 0;
  for(int imagex = 0; imagex < cols; imagex++) {
    for(int imagey = 0; imagey < rows; imagey++) {
      mean += rgbtogray(GetRPixel(image, cols, imagex, imagey), GetGPixel(image, cols, imagex, imagey), GetBPixel(image, cols, imagex, imagey));
    }
  }
  return mean / (cols * rows);
}

/*Here we are calculating Single Mean Threshold Value by using the function SingleMeanThreshold*/
void SingleMeanThreshold(unsigned char *image, unsigned char *output, int cols, int rows) {
  double threshold = CalculateMeanSingleThreshold(image, cols, rows);
  
  for(int imagex = 0; imagex < cols; imagex++) {
    for(int imagey = 0; imagey < rows; imagey++) {
      if(rgbtogray(GetRPixel(image, cols, imagex, imagey), GetGPixel(image, cols, imagex, imagey), GetBPixel(image, cols, imagex, imagey)) < threshold) {
        PutBPixel(output, cols, imagex, imagey, 0);
        PutGPixel(output, cols, imagex, imagey, 0);
        PutRPixel(output, cols, imagex, imagey, 0);
      }
    }
  }
}


void main()
{
  unsigned char *image;
  unsigned char *image1;
  char filename[100]; /*Length of the file */
  unsigned char sing_thre; /*Assigning the value to sing_thre*/
  unsigned char adap_thre; /*Assigning the value to adap_thre*/
  int cols, rows, value1, value2;
  char red,blue,green; 
  /* declaring the variables of red, green, blue */
  /*Helps to enter input file name*/
  printf("Enter the input for the filename : \n");
  scanf("%s", filename);
  image = ReadPPM(filename,&cols, &rows);
  image1 = CreatePPM(cols, rows);
  sing_thre = CreatePPM(cols, rows);
  adap_thre = CreatePPM(cols, rows);
 
  for(value1=0;value1<rows;value1++)
  {
    for(value2=0;value2<cols;value2++)
    {
          red=GetRPixel(image,cols,value2,value1);
          blue=GetBPixel(image, cols,value2,value1);
          green=GetGPixel(image, cols,value2,value1);
          PutRPixel(image1, cols, value2, value1, red);
          PutGPixel(image1, cols, value2, value1, green);
          PutBPixel(image1, cols, value2, value1, blue);

          PutRPixel(sing_thre, cols, value2, value1, 255);
          PutGPixel(sing_thre, cols, value2, value1, 255);
          PutBPixel(sing_thre, cols, value2, value1, 255);

          PutRPixel(adap_thre, cols, value2, value1, 255);
          PutGPixel(adap_thre, cols, value2, value1, 255);
          PutBPixel(adap_thre, cols, value2, value1, 255);
    }
  }
  
  /*Single Mean Threshold Value*/
  SingleMeanThreshold(image1, sing_thre, cols, rows);
  /*Adaptive Mean Threshold Value*/
  AdaptiveMeanThreshold(image1, adap_thre, cols, rows, 50);
  /*Writes into the Single Threshold Output File*/
  WritePPM("sing_thre.ppm", sing_thre, rows, cols);
  /*Writes into the Adaptive Threshold Output File*/
  WritePPM("adap_thre.ppm", adap_thre, rows, cols);
}